export const Profile = () => {
  return (
    <>
      <section class="profile-section">
        <h1>Профиль пользователя</h1>
        <div class="user-info">
          <p>
            <strong>Имя:</strong> Иван Петров
          </p>
          <p>
            <strong>Телефон:</strong> +7 (999) 123-45-67
          </p>
          <p>
            <strong>Должность:</strong> Прораб
          </p>
        </div>
      </section>

      <section class="projects-section">
        <h2>Проекты</h2>
        <div class="projects-table">
          <div class="project-card">
            <h3>Строительство жилого комплекса "Солнечный"</h3>
            <p>
              <strong>Дата начала:</strong> 01.03.2024
            </p>
            <p>
              <strong>Дата окончания:</strong> 30.12.2024
            </p>
          </div>

          <div class="project-card">
            <h3>Реконструкция школы №12</h3>
            <p>
              <strong>Дата начала:</strong> 15.04.2023
            </p>
            <p>
              <strong>Дата окончания:</strong> 15.11.2023
            </p>
          </div>

          <div class="project-card">
            <h3>Офисное здание на ул. Ленина</h3>
            <p>
              <strong>Дата начала:</strong> 10.01.2025
            </p>
            <p>
              <strong>Дата окончания:</strong> 01.09.2025
            </p>
          </div>
        </div>
      </section>
    </>
  );
};
