import { Link, useNavigate } from "react-router-dom";

export const Login = () => {
  const navigate = useNavigate();
  return (
    <>
      <section class="auth-section">
        <h1>Вход</h1>
        <form
          action="/login"
          method="POST"
          class="auth-form"
          onSubmit={(e) => {
            e.preventDefault();
            navigate("/profile");
          }}
        >
          <label for="email">Email:</label>
          <input type="email" id="email" name="email" required />

          <label for="password">Пароль:</label>
          <input type="password" id="password" name="password" required />

          <button type="submit">Войти</button>
        </form>
        <p>
          Нет аккаунта? <Link to="/register">Зарегистрироваться</Link>
        </p>
      </section>
    </>
  );
};
