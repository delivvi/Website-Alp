import { Hero } from "../components/Hero";
import { AboutUs } from "../components/AboutUs.jsx";
import { Services } from "../components/Services";
import { Form } from "../components/Form";
import { Contacts } from "../components/Contacts";
export const Main = () => {
  return (
    <>
      <Hero />
      <AboutUs />
      <Services />
      <Contacts />
    </>
  );
};
