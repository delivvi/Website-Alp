import { Link, useNavigate } from "react-router-dom";

export const Register = () => {
  const navigate = useNavigate();
  return (
    <>
      <section class="auth-section">
        <h1>Регистрация</h1>
        <form
          action="/register"
          method="POST"
          class="auth-form"
          onSubmit={(e) => {
            e.preventDefault();
            navigate("/profile");
          }}
        >
          <label for="email">Email:</label>
          <input type="email" id="email" name="email" required />

          <label for="password">Пароль:</label>
          <input type="password" id="password" name="password" required />

          <button type="submit">Зарегистрироваться</button>
        </form>
        <p>
          Уже есть аккаунт? <Link to="/login">Войти</Link>
        </p>
      </section>
    </>
  );
};
