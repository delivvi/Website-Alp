import { Header } from "./components/Header";
import { Footer } from "./components/Footer";
import "./App.css";
import { Route, Routes, useLocation } from "react-router-dom";
import { Main } from "./pages/Main.jsx";
import { useEffect, useState } from "react";
import { Login } from "./pages/Login.jsx";
import { Register } from "./pages/Register.jsx";
import { Profile } from "./pages/Profile.jsx";

function App() {
  const location = useLocation();
  const [displayLocation, setDisplayLocation] = useState(location);
  const [stage, setStage] = useState("fadeIn");

  useEffect(() => {
    if (location !== displayLocation) {
      setStage("fadeOut");
    }
  });
  return (
    <>
      <Header />
      <div className="container">
        <div
          className={"main" + " " + stage}
          onAnimationEnd={() => {
            if (stage === "fadeOut") {
              setStage("fadeIn");
              setDisplayLocation(location);
            }
          }}
        >
          <Routes location={displayLocation}>
            <Route index element={<Main />} />
            <Route path="login" element={<Login />} />
            <Route path="register" element={<Register />} />
            <Route path="profile" element={<Profile />} />
          </Routes>
        </div>
      </div>
      <Footer />
    </>
  );
}

export default App;
