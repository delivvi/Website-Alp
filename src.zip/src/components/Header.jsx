import { useState } from "react";
import { Link } from "react-router-dom";

export const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header>
      <div className="logo">
        <img src="/лого.png" alt="Логотип" />
        <p>
          Строим <span>надежно</span>
        </p>
      </div>

      <div
        className={`burger ${menuOpen ? "open" : ""}`}
        onClick={() => setMenuOpen(!menuOpen)}
      >
        <span></span>
        <span></span>
        <span></span>
      </div>

      <div className={`links ${menuOpen ? "active" : ""}`}>
        <ul>
          <li>
            <Link to="/">Главная</Link>
          </li>
          <li>
            <Link to="/profile">Проекты</Link>
          </li>
          <li>
            <Link to="/login">Для сотрудников</Link>
          </li>
          <li>
            <Link to="/">Контакты</Link>
          </li>
        </ul>
        <button>Подобрать проект</button>
      </div>
    </header>
  );
};
