import { useNavigate } from "react-router-dom";

export const Contacts = () => {
  const navigate = useNavigate();
  return (
    <>
      <section class="form">
        <div class="image">
          <img src="https://i.ibb.co/WDJfppr/image.png" />
        </div>
        <div class="wrapper">
          <div class="card">
            <div class="card-header">
              <h3>Оставьте ваши контактные данные</h3>
              <p>Мы свяжемся с вами в ближайшее время</p>
            </div>
            <div class="card-content">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  navigate("/profile");
                }}
              >
                <input type="text" placeholder="Имя" id="name" />
                <input type="tel" placeholder="+7(___)___-__-__" id="phone" />
                <input type="email" placeholder="E-mail" id="email" />
                <button type="submit">Заказать консультацию</button>
              </form>
              <div class="check">
                <input type="checkbox" name="agreement" id="agree" />
                <label for="agree">
                  Даю согласие на обработку
                  <a href="#">персональных данных</a>
                </label>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};
