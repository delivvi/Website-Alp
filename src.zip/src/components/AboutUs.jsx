export const AboutUs = () => {
  return (
    <>
      <section class="about-us">
        <h2>Наши цели</h2>
        <div class="advan-card-row">
          <div class="advan-card">
            <i class="fa-solid fa-list-check"></i>
            <p class="advan-card-heading">Эффективность</p>
            <p>
              Использование EPC контракта, постоянная проверка качества
              выполнения проекта
            </p>
          </div>
          <div class="advan-card">
            <i class="fa fa-handshake"></i>
            <p class="advan-card-heading">Качество</p>
            <p>Создание нового подхода к качеству и срокам строительства</p>
          </div>
          <div class="advan-card">
            <i class="fa fa-university"></i>
            <p class="advan-card-heading">Профессионализм</p>
            <p>Над проектами работают только специалисты высокого класса</p>
          </div>
          <div class="advan-card">
            <i class="fas fa-phone-volume"></i>
            <p class="advan-card-heading">Доступность</p>
            <p>
              Забота о пожеланиях заказчика, постоянная связь с руководителем
              проекта
            </p>
          </div>
        </div>
      </section>
    </>
  );
};
