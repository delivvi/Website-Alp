import "./Hero.css";
export const Hero = () => {
  return (
    <>
      <section class="hero">
        <div class="card">
          <div class="card-heading">
            <h1>
              Выбирая нас - <br />
              выбираете <span>надежность</span>
            </h1>
            <h3>Проектирование на высочайшем уровне</h3>
            <button>Заказать консультацию</button>
          </div>
          <div class="card-image">
            <img src="https://i.ibb.co/Wk2phcK/image.png" />
          </div>
        </div>
        <div class="company-info">
          <h2>
            Мы - компания «АЛЬП<span>ПРОФИТ</span>»
          </h2>
          <p>
            ООО «АЛЬППРОФИТ» - молодая, развивающаяся компания. За нашими
            плечами большой опыт работы по реализации сложных проектов. Нам
            доверяет множество надежных партнеров среди подрядных организаций,
            поставщиков строительной техники и поставщиков материалов и
            оборудования.
          </p>
        </div>
      </section>
    </>
  );
};
