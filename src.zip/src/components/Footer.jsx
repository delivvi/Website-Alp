import { Link } from "react-router-dom";

export const Footer = () => {
  return (
    <>
      <footer class="footer">
        <div class="footer-inner">
          <div class="footer-section">
            <h4>Альпрофит</h4>
            <p>Компания по реализации строительных проектов.</p>
          </div>
          <div class="footer-section">
            <h4>Навигация</h4>
            <ul>
              <li>
                <Link to="/">Главная</Link>
              </li>
              <li>
                <Link to="/profile">Проекты</Link>
              </li>
              <li>
                <Link to="/">О нас</Link>
              </li>
            </ul>
          </div>
          <div class="footer-section">
            <h4>Контакты</h4>
            <p>Email: alprofit@gmail.com</p>
            <p>Контактынй телефон: +8(888)8888888</p>
          </div>
        </div>
        <div class="footer-bottom">&copy; 2025 Альпрофит</div>
      </footer>
    </>
  );
};
